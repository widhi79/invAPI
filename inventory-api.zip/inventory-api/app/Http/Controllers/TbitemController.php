<?php

namespace App\Http\Controllers;

use App\Models\Tbitem;
use Illuminate\Http\Request;

class TbitemController extends Controller
{
    public function index()
    {
        $inventories = Tbitem::all();

        return response()->json($inventories);
    }

    public function show($id)
    {
        $inventory = Tbitem::find($id);

        if (!$inventory) {
            return response()->json(['message' => 'Item Tidak Ditemukan'], 404);
        }

        return response()->json($inventory);
    }

    public function store(Request $request)
    {
        $this->validate($request, [
            'name' => 'required',
            'qty' => 'required|integer'
        ]);

        $inventory = Tbitem::create($request->all());

        return response()->json($inventory, 201);
    }

    public function update(Request $request, $id)
    {
        $inventory = Tbitem::find($id);

        if (!$inventory) {
            return response()->json(['message' => 'Item Tidak Ditemukan'], 404);
        }

        $this->validate($request, [
            'name' => 'required',
            'qty' => 'required|integer'
        ]);

        $inventory->update($request->all());

        return response()->json($inventory);
    }

    public function destroy($id)
    {
        $inventory = Tbitem::find($id);

        if (!$inventory) {
            return response()->json(['message' => 'Item Tidak Ditemukan'], 404);
        }

        $inventory->delete();

        return response()->json(['message' => 'Item Telah Dihapus']);
    }
}
